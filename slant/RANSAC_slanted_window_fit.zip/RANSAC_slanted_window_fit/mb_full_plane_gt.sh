# shellcheck disable=SC2154
CUDA_VISIBLE_DEVICES=0 python mb_full_plane_gt.py