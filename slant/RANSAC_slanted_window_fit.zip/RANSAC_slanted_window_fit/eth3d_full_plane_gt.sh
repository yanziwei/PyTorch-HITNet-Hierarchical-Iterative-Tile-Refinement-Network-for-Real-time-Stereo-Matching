# shellcheck disable=SC2154
CUDA_VISIBLE_DEVICES=0 python eth3d_full_plane_gt.py